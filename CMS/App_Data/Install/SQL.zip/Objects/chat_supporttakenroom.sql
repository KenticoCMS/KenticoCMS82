CREATE TABLE [Chat_SupportTakenRoom] (
		[ChatSupportTakenRoomID]                   [int] IDENTITY(1, 1) NOT NULL,
		[ChatSupportTakenRoomChatUserID]           [int] NULL,
		[ChatSupportTakenRoomRoomID]               [int] NOT NULL,
		[ChatSupportTakenRoomResolvedDateTime]     [datetime2](7) NULL,
		[ChatSupportTakenRoomLastModification]     [datetime2](7) NOT NULL
) 
ALTER TABLE [Chat_SupportTakenRoom]
	ADD
	CONSTRAINT [PK_Chat_SupportTakenRooms]
	PRIMARY KEY
	CLUSTERED
	([ChatSupportTakenRoomID])
	
ALTER TABLE [Chat_SupportTakenRoom]
	ADD
	CONSTRAINT [DEFAULT_Chat_SupportTakenRoom_ChatSupportTakenRoomLastModification]
	DEFAULT ('4/16/2012 5:11:30 PM') FOR [ChatSupportTakenRoomLastModification]
ALTER TABLE [Chat_SupportTakenRoom]
	ADD
	CONSTRAINT [DEFAULT_Chat_SupportTakenRoom_ChatSupportTakenRoomRoomID]
	DEFAULT ((0)) FOR [ChatSupportTakenRoomRoomID]
CREATE NONCLUSTERED INDEX [IX_Chat_SupportTakenRoom_ChatSupportTakenRoomChatUserID]
	ON [Chat_SupportTakenRoom] ([ChatSupportTakenRoomChatUserID]) 
CREATE NONCLUSTERED INDEX [IX_Chat_SupportTakenRoom_ChatSupportTakenRoomRoomID]
	ON [Chat_SupportTakenRoom] ([ChatSupportTakenRoomRoomID]) 

ALTER TABLE [Chat_SupportTakenRoom]
	WITH CHECK
	ADD CONSTRAINT [FK_Chat_SupportTakenRoom_Chat_Room]
	FOREIGN KEY ([ChatSupportTakenRoomRoomID]) REFERENCES [Chat_Room] ([ChatRoomID])
ALTER TABLE [Chat_SupportTakenRoom]
	CHECK CONSTRAINT [FK_Chat_SupportTakenRoom_Chat_Room]
ALTER TABLE [Chat_SupportTakenRoom]
	WITH CHECK
	ADD CONSTRAINT [FK_Chat_SupportTakenRoom_Chat_User]
	FOREIGN KEY ([ChatSupportTakenRoomChatUserID]) REFERENCES [Chat_User] ([ChatUserID])
ALTER TABLE [Chat_SupportTakenRoom]
	CHECK CONSTRAINT [FK_Chat_SupportTakenRoom_Chat_User]
