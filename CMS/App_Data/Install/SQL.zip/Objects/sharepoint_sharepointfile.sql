CREATE TABLE [SharePoint_SharePointFile] (
		[SharePointFileID]                      [int] IDENTITY(1, 1) NOT NULL,
		[SharePointFileGUID]                    [uniqueidentifier] NOT NULL,
		[SharePointFileSiteID]                  [int] NOT NULL,
		[SharePointFileName]                    [nvarchar](150) NOT NULL,
		[SharePointFileExtension]               [nvarchar](150) NULL,
		[SharePointFileMimeType]                [nvarchar](255) NULL,
		[SharePointFileETag]                    [nvarchar](255) NULL,
		[SharePointFileSize]                    [bigint] NOT NULL,
		[SharePointFileServerLastModified]      [datetime2](7) NOT NULL,
		[SharePointFileServerRelativeURL]       [nvarchar](300) NOT NULL,
		[SharePointFileSharePointLibraryID]     [int] NOT NULL,
		[SharePointFileBinary]                  [varbinary](max) NULL
)  
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [PK_SharePoint_SharePointFile]
	PRIMARY KEY
	CLUSTERED
	([SharePointFileID])
	
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointFile_SharePointFileETag]
	DEFAULT (N'') FOR [SharePointFileETag]
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointFile_SharePointFileExtension]
	DEFAULT (N'') FOR [SharePointFileExtension]
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointFile_SharePointFileGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [SharePointFileGUID]
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointFile_SharePointFileMimeType]
	DEFAULT (N'') FOR [SharePointFileMimeType]
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointFile_SharePointFileName]
	DEFAULT (N'') FOR [SharePointFileName]
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointFile_SharePointFileServerRelativeURL]
	DEFAULT (N'') FOR [SharePointFileServerRelativeURL]
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointFile_SharePointFileSharePointLibraryID]
	DEFAULT ((0)) FOR [SharePointFileSharePointLibraryID]
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointFile_SharePointFileSiteID]
	DEFAULT ((0)) FOR [SharePointFileSiteID]
ALTER TABLE [SharePoint_SharePointFile]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointFile_SharePointFileSize]
	DEFAULT ((0)) FOR [SharePointFileSize]
CREATE NONCLUSTERED INDEX [IX_SharePoint_SharePointFile_SharePointFileSiteID]
	ON [SharePoint_SharePointFile] ([SharePointFileSiteID]) 
CREATE UNIQUE NONCLUSTERED INDEX [UQ_SharePoint_SharePointFile_LibraryID_ServerRelativeURL]
	ON [SharePoint_SharePointFile] ([SharePointFileSharePointLibraryID], [SharePointFileServerRelativeURL]) 

ALTER TABLE [SharePoint_SharePointFile]
	WITH CHECK
	ADD CONSTRAINT [FK_SharePoint_SharePointFile_CMS_Site]
	FOREIGN KEY ([SharePointFileSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [SharePoint_SharePointFile]
	CHECK CONSTRAINT [FK_SharePoint_SharePointFile_CMS_Site]
ALTER TABLE [SharePoint_SharePointFile]
	WITH CHECK
	ADD CONSTRAINT [FK_SharePoint_SharePointFile_SharePoint_SharePointLibrary]
	FOREIGN KEY ([SharePointFileSharePointLibraryID]) REFERENCES [SharePoint_SharePointLibrary] ([SharePointLibraryID])
ALTER TABLE [SharePoint_SharePointFile]
	CHECK CONSTRAINT [FK_SharePoint_SharePointFile_SharePoint_SharePointLibrary]
