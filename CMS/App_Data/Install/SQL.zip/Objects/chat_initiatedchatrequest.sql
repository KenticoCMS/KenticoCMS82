CREATE TABLE [Chat_InitiatedChatRequest] (
		[InitiatedChatRequestID]                      [int] IDENTITY(1, 1) NOT NULL,
		[InitiatedChatRequestUserID]                  [int] NULL,
		[InitiatedChatRequestContactID]               [int] NULL,
		[InitiatedChatRequestRoomID]                  [int] NOT NULL,
		[InitiatedChatRequestState]                   [int] NOT NULL,
		[InitiatedChatRequestInitiatorName]           [nvarchar](100) NOT NULL,
		[InitiatedChatRequestInitiatorChatUserID]     [int] NOT NULL,
		[InitiatedChatRequestLastModification]        [datetime2](7) NOT NULL,
		CONSTRAINT [UQ_Chat_InitiatedChatRequest_RoomID]
		UNIQUE
		NONCLUSTERED
		([InitiatedChatRequestRoomID])
		
,
		CONSTRAINT [UQ_Chat_InitiatedChatRequest_UserIDContactID]
		UNIQUE
		NONCLUSTERED
		([InitiatedChatRequestUserID], [InitiatedChatRequestContactID])
		
) 
ALTER TABLE [Chat_InitiatedChatRequest]
	ADD
	CONSTRAINT [PK_Chat_InitiatedChatRequest]
	PRIMARY KEY
	CLUSTERED
	([InitiatedChatRequestID])
	
ALTER TABLE [Chat_InitiatedChatRequest]
	ADD
	CONSTRAINT [DEFAULT_Chat_InitiatedChatRequest_InitiatedChatRequestState]
	DEFAULT ((1)) FOR [InitiatedChatRequestState]
CREATE NONCLUSTERED INDEX [IX_Chat_InitiatedChatRequest_InitiatedChatRequestInitiatorChatUserID]
	ON [Chat_InitiatedChatRequest] ([InitiatedChatRequestInitiatorChatUserID]) 
CREATE NONCLUSTERED INDEX [IX_Chat_InitiatedChatRequest_InitiatedChatRequestRoomID]
	ON [Chat_InitiatedChatRequest] ([InitiatedChatRequestRoomID]) 
CREATE NONCLUSTERED INDEX [IX_Chat_InitiatedChatRequest_InitiatedChatRequestUserID]
	ON [Chat_InitiatedChatRequest] ([InitiatedChatRequestUserID]) 

ALTER TABLE [Chat_InitiatedChatRequest]
	WITH CHECK
	ADD CONSTRAINT [FK_Chat_InitiatedChatRequest_CMS_User]
	FOREIGN KEY ([InitiatedChatRequestUserID]) REFERENCES [CMS_User] ([UserID])
ALTER TABLE [Chat_InitiatedChatRequest]
	CHECK CONSTRAINT [FK_Chat_InitiatedChatRequest_CMS_User]
ALTER TABLE [Chat_InitiatedChatRequest]
	WITH CHECK
	ADD CONSTRAINT [FK_Chat_InitiatedChatRequest_Chat_Room]
	FOREIGN KEY ([InitiatedChatRequestRoomID]) REFERENCES [Chat_Room] ([ChatRoomID])
ALTER TABLE [Chat_InitiatedChatRequest]
	CHECK CONSTRAINT [FK_Chat_InitiatedChatRequest_Chat_Room]
ALTER TABLE [Chat_InitiatedChatRequest]
	WITH CHECK
	ADD CONSTRAINT [FK_Chat_InitiatedChatRequest_Chat_User]
	FOREIGN KEY ([InitiatedChatRequestInitiatorChatUserID]) REFERENCES [Chat_User] ([ChatUserID])
ALTER TABLE [Chat_InitiatedChatRequest]
	CHECK CONSTRAINT [FK_Chat_InitiatedChatRequest_Chat_User]
