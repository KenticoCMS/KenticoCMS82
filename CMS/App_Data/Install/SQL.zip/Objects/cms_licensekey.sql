CREATE TABLE [CMS_LicenseKey] (
		[LicenseKeyID]          [int] IDENTITY(1, 1) NOT NULL,
		[LicenseDomain]         [nvarchar](255) NULL,
		[LicenseKey]            [nvarchar](max) NULL,
		[LicenseEdition]        [nvarchar](200) NULL,
		[LicenseExpiration]     [nvarchar](200) NULL,
		[LicensePackages]       [nvarchar](100) NULL,
		[LicenseServers]        [int] NULL
)  
ALTER TABLE [CMS_LicenseKey]
	ADD
	CONSTRAINT [PK_CMS_LicenseKey]
	PRIMARY KEY
	NONCLUSTERED
	([LicenseKeyID])
	
CREATE CLUSTERED INDEX [IX_CMS_LicenseKey_LicenseDomain]
	ON [CMS_LicenseKey] ([LicenseDomain]) 

