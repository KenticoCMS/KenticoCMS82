CREATE TABLE [CMS_TimeZone] (
		[TimeZoneID]                [int] IDENTITY(1, 1) NOT NULL,
		[TimeZoneName]              [nvarchar](200) NOT NULL,
		[TimeZoneDisplayName]       [nvarchar](200) NOT NULL,
		[TimeZoneGMT]               [float] NOT NULL,
		[TimeZoneDaylight]          [bit] NULL,
		[TimeZoneRuleStartIn]       [datetime2](7) NOT NULL,
		[TimeZoneRuleStartRule]     [nvarchar](200) NOT NULL,
		[TimeZoneRuleEndIn]         [datetime2](7) NOT NULL,
		[TimeZoneRuleEndRule]       [nvarchar](200) NOT NULL,
		[TimeZoneGUID]              [uniqueidentifier] NOT NULL,
		[TimeZoneLastModified]      [datetime2](7) NOT NULL
) 
ALTER TABLE [CMS_TimeZone]
	ADD
	CONSTRAINT [PK_CMS_TimeZone]
	PRIMARY KEY
	NONCLUSTERED
	([TimeZoneID])
	
ALTER TABLE [CMS_TimeZone]
	ADD
	CONSTRAINT [DEFAULT_CMS_TimeZone_TimeZoneDaylight]
	DEFAULT ((0)) FOR [TimeZoneDaylight]
ALTER TABLE [CMS_TimeZone]
	ADD
	CONSTRAINT [DEFAULT_CMS_TimeZone_TimeZoneGMT]
	DEFAULT ((0)) FOR [TimeZoneGMT]
CREATE CLUSTERED INDEX [IX_CMS_TimeZone_TimeZoneDisplayName]
	ON [CMS_TimeZone] ([TimeZoneDisplayName])
	
