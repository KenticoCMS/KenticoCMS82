CREATE TABLE [COM_CouponCode] (
		[CouponCodeID]               [int] IDENTITY(1, 1) NOT NULL,
		[CouponCodeCode]             [nvarchar](200) NOT NULL,
		[CouponCodeUseCount]         [int] NULL,
		[CouponCodeUseLimit]         [int] NULL,
		[CouponCodeDiscountID]       [int] NOT NULL,
		[CouponCodeLastModified]     [datetime2](7) NOT NULL,
		[CouponCodeGUID]             [uniqueidentifier] NOT NULL
) 
ALTER TABLE [COM_CouponCode]
	ADD
	CONSTRAINT [PK_COM_CouponCode]
	PRIMARY KEY
	CLUSTERED
	([CouponCodeID])
	
ALTER TABLE [COM_CouponCode]
	ADD
	CONSTRAINT [DEFAULT_COM_CouponCode_CouponCodeCode]
	DEFAULT ('') FOR [CouponCodeCode]
ALTER TABLE [COM_CouponCode]
	ADD
	CONSTRAINT [DEFAULT_COM_CouponCode_CouponCodeDiscountID]
	DEFAULT ((0)) FOR [CouponCodeDiscountID]
CREATE NONCLUSTERED INDEX [IX_COM_CouponCode_CouponCodeDiscountID]
	ON [COM_CouponCode] ([CouponCodeDiscountID]) 

ALTER TABLE [COM_CouponCode]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_CouponCode_CouponCodeDiscountID_COM_Discount]
	FOREIGN KEY ([CouponCodeDiscountID]) REFERENCES [COM_Discount] ([DiscountID])
ALTER TABLE [COM_CouponCode]
	CHECK CONSTRAINT [FK_COM_CouponCode_CouponCodeDiscountID_COM_Discount]
