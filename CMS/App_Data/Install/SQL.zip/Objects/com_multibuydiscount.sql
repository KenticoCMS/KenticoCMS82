CREATE TABLE [COM_MultiBuyDiscount] (
		[MultiBuyDiscountID]                        [int] IDENTITY(1, 1) NOT NULL,
		[MultiBuyDiscountDisplayName]               [nvarchar](200) NOT NULL,
		[MultiBuyDiscountName]                      [nvarchar](200) NOT NULL,
		[MultiBuyDiscountDescription]               [nvarchar](max) NULL,
		[MultiBuyDiscountEnabled]                   [bit] NOT NULL,
		[MultiBuyDiscountGUID]                      [uniqueidentifier] NOT NULL,
		[MultiBuyDiscountLastModified]              [datetime2](7) NOT NULL,
		[MultiBuyDiscountSiteID]                    [int] NULL,
		[MultiBuyDiscountPriority]                  [float] NULL,
		[MultiBuyDiscountApplyFurtherDiscounts]     [bit] NOT NULL,
		[MultiBuyDiscountMinimumBuyCount]           [int] NOT NULL,
		[MultiBuyDiscountValidFrom]                 [datetime2](7) NULL,
		[MultiBuyDiscountValidTo]                   [datetime2](7) NULL,
		[MultiBuyDiscountCustomerRestriction]       [nvarchar](200) NOT NULL,
		[MultiBuyDiscountRoles]                     [nvarchar](400) NULL,
		[MultiBuyDiscountApplyToSKUID]              [int] NULL,
		[MultiBuyDiscountLimitPerOrder]             [int] NULL,
		[MultiBuyDiscountUsesCoupons]               [bit] NULL,
		[MultiBuyDiscountValue]                     [float] NULL,
		[MultiBuyDiscountIsFlat]                    [bit] NULL,
		[MultiBuyDiscountAutoAddEnabled]            [bit] NOT NULL
)  
ALTER TABLE [COM_MultiBuyDiscount]
	ADD
	CONSTRAINT [PK_COM_MultiBuyDiscount]
	PRIMARY KEY
	CLUSTERED
	([MultiBuyDiscountID])
	
ALTER TABLE [COM_MultiBuyDiscount]
	ADD
	CONSTRAINT [DEFAULT_COM_MultiBuyDiscount_MultiBuyDiscountApplyFurtherDiscounts]
	DEFAULT ((1)) FOR [MultiBuyDiscountApplyFurtherDiscounts]
ALTER TABLE [COM_MultiBuyDiscount]
	ADD
	CONSTRAINT [DEFAULT_COM_MultiBuyDiscount_MultiBuyDiscountAutoAddEnabled]
	DEFAULT ((1)) FOR [MultiBuyDiscountAutoAddEnabled]
ALTER TABLE [COM_MultiBuyDiscount]
	ADD
	CONSTRAINT [DEFAULT_COM_MultiBuyDiscount_MultiBuyDiscountCustomerRestriction]
	DEFAULT (N'All') FOR [MultiBuyDiscountCustomerRestriction]
ALTER TABLE [COM_MultiBuyDiscount]
	ADD
	CONSTRAINT [DEFAULT_COM_MultiBuyDiscount_MultiBuyDiscountEnabled]
	DEFAULT ((1)) FOR [MultiBuyDiscountEnabled]
ALTER TABLE [COM_MultiBuyDiscount]
	ADD
	CONSTRAINT [DEFAULT_COM_MultiBuyDiscount_MultiBuyDiscountIsFlat]
	DEFAULT ((1)) FOR [MultiBuyDiscountIsFlat]
ALTER TABLE [COM_MultiBuyDiscount]
	ADD
	CONSTRAINT [DEFAULT_COM_MultiBuyDiscount_MultiBuyDiscountMinimumBuyCount]
	DEFAULT ((1)) FOR [MultiBuyDiscountMinimumBuyCount]
ALTER TABLE [COM_MultiBuyDiscount]
	ADD
	CONSTRAINT [DEFAULT_COM_MultiBuyDiscount_MultiBuyDiscountUsesCoupons]
	DEFAULT ((0)) FOR [MultiBuyDiscountUsesCoupons]
CREATE NONCLUSTERED INDEX [IX_COM_MultiBuyDiscount_MultiBuyDiscountApplyToSKUID]
	ON [COM_MultiBuyDiscount] ([MultiBuyDiscountApplyToSKUID]) 
CREATE NONCLUSTERED INDEX [IX_COM_MultiBuyDiscount_MultiBuyDiscountSiteID]
	ON [COM_MultiBuyDiscount] ([MultiBuyDiscountSiteID]) 

ALTER TABLE [COM_MultiBuyDiscount]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_MultiBuyDiscount_MultiBuyDiscountApplyToSKUID_COM_SKU]
	FOREIGN KEY ([MultiBuyDiscountApplyToSKUID]) REFERENCES [COM_SKU] ([SKUID])
ALTER TABLE [COM_MultiBuyDiscount]
	CHECK CONSTRAINT [FK_COM_MultiBuyDiscount_MultiBuyDiscountApplyToSKUID_COM_SKU]
ALTER TABLE [COM_MultiBuyDiscount]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_MultiBuyDiscount_MultiBuyDiscountSiteID_CMS_Site]
	FOREIGN KEY ([MultiBuyDiscountSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [COM_MultiBuyDiscount]
	CHECK CONSTRAINT [FK_COM_MultiBuyDiscount_MultiBuyDiscountSiteID_CMS_Site]
