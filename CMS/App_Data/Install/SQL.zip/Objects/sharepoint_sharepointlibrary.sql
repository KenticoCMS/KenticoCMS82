CREATE TABLE [SharePoint_SharePointLibrary] (
		[SharePointLibraryID]                         [int] IDENTITY(1, 1) NOT NULL,
		[SharePointLibraryName]                       [nvarchar](100) NOT NULL,
		[SharePointLibrarySharePointConnectionID]     [int] NULL,
		[SharePointLibraryListTitle]                  [nvarchar](100) NOT NULL,
		[SharePointLibrarySynchronizationPeriod]      [int] NOT NULL,
		[SharePointLibraryGUID]                       [uniqueidentifier] NOT NULL,
		[SharePointLibrarySiteID]                     [int] NOT NULL,
		[SharePointLibraryDisplayName]                [nvarchar](100) NOT NULL,
		[SharePointLibraryLastModified]               [datetime2](7) NOT NULL,
		[SharePointLibraryListType]                   [int] NOT NULL
) 
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [PK_SharePoint_SharePointLibrary]
	PRIMARY KEY
	CLUSTERED
	([SharePointLibraryID])
	
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointLibrary_SharePointLibraryDisplayName]
	DEFAULT (N'') FOR [SharePointLibraryDisplayName]
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointLibrary_SharePointLibraryGuid]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [SharePointLibraryGUID]
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointLibrary_SharePointLibraryLastModified]
	DEFAULT ('10/3/2014 2:45:04 PM') FOR [SharePointLibraryLastModified]
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointLibrary_SharePointLibraryListTitle]
	DEFAULT (N'') FOR [SharePointLibraryListTitle]
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointLibrary_SharePointLibraryListType]
	DEFAULT ((0)) FOR [SharePointLibraryListType]
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointLibrary_SharePointLibraryName]
	DEFAULT (N'') FOR [SharePointLibraryName]
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointLibrary_SharePointLibrarySharepointConnectionID]
	DEFAULT ((0)) FOR [SharePointLibrarySharePointConnectionID]
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointLibrary_SharePointLibrarySiteID]
	DEFAULT ((0)) FOR [SharePointLibrarySiteID]
ALTER TABLE [SharePoint_SharePointLibrary]
	ADD
	CONSTRAINT [DEFAULT_SharePoint_SharePointLibrary_SharePointLibrarySynchronizationPeriod]
	DEFAULT ((720)) FOR [SharePointLibrarySynchronizationPeriod]
CREATE NONCLUSTERED INDEX [IX_SharePoint_SharePointLibrary_SharePointLibrarySharepointConnectionID]
	ON [SharePoint_SharePointLibrary] ([SharePointLibrarySharePointConnectionID]) 
CREATE NONCLUSTERED INDEX [IX_SharePoint_SharePointLibrary_SharePointlibrarySiteID]
	ON [SharePoint_SharePointLibrary] ([SharePointLibrarySiteID]) 

ALTER TABLE [SharePoint_SharePointLibrary]
	WITH CHECK
	ADD CONSTRAINT [FK_SharePoint_SharePointLibrary_CMS_Site]
	FOREIGN KEY ([SharePointLibrarySiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [SharePoint_SharePointLibrary]
	CHECK CONSTRAINT [FK_SharePoint_SharePointLibrary_CMS_Site]
ALTER TABLE [SharePoint_SharePointLibrary]
	WITH CHECK
	ADD CONSTRAINT [FK_SharePoint_SharePointLibrary_SharePoint_SharePointConnection]
	FOREIGN KEY ([SharePointLibrarySharePointConnectionID]) REFERENCES [SharePoint_SharePointConnection] ([SharePointConnectionID])
ALTER TABLE [SharePoint_SharePointLibrary]
	CHECK CONSTRAINT [FK_SharePoint_SharePointLibrary_SharePoint_SharePointConnection]
