CREATE TABLE [PM_ProjectStatus] (
		[StatusID]               [int] IDENTITY(1, 1) NOT NULL,
		[StatusName]             [nvarchar](200) NOT NULL,
		[StatusDisplayName]      [nvarchar](200) NOT NULL,
		[StatusOrder]            [int] NOT NULL,
		[StatusColor]            [nvarchar](7) NULL,
		[StatusIcon]             [nvarchar](450) NULL,
		[StatusGUID]             [uniqueidentifier] NOT NULL,
		[StatusLastModified]     [datetime2](7) NOT NULL,
		[StatusEnabled]          [bit] NOT NULL,
		[StatusIsFinished]       [bit] NOT NULL,
		[StatusIsNotStarted]     [bit] NOT NULL
) 
ALTER TABLE [PM_ProjectStatus]
	ADD
	CONSTRAINT [PK_PM_ProjectStatus]
	PRIMARY KEY
	CLUSTERED
	([StatusID])
	
ALTER TABLE [PM_ProjectStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectStatus_StatusDisplayName]
	DEFAULT (N'') FOR [StatusDisplayName]
ALTER TABLE [PM_ProjectStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectStatus_StatusEnabled]
	DEFAULT ((1)) FOR [StatusEnabled]
ALTER TABLE [PM_ProjectStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectStatus_StatusGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [StatusGUID]
ALTER TABLE [PM_ProjectStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectStatus_StatusIsFinished]
	DEFAULT ((0)) FOR [StatusIsFinished]
ALTER TABLE [PM_ProjectStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectStatus_StatusIsNotStarted]
	DEFAULT ((0)) FOR [StatusIsNotStarted]
ALTER TABLE [PM_ProjectStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectStatus_StatusLastModified]
	DEFAULT ('11/7/2013 9:21:32 AM') FOR [StatusLastModified]
ALTER TABLE [PM_ProjectStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectStatus_StatusName]
	DEFAULT (N'') FOR [StatusName]
ALTER TABLE [PM_ProjectStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectStatus_StatusOrder]
	DEFAULT ((0)) FOR [StatusOrder]

