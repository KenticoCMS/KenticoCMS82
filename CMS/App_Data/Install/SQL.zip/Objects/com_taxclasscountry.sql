CREATE TABLE [COM_TaxClassCountry] (
		[TaxClassCountryID]     [int] IDENTITY(1, 1) NOT NULL,
		[TaxClassID]            [int] NOT NULL,
		[CountryID]             [int] NOT NULL,
		[TaxValue]              [float] NOT NULL,
		[IsFlatValue]           [bit] NOT NULL
) 
ALTER TABLE [COM_TaxClassCountry]
	ADD
	CONSTRAINT [PK_COM_TaxClassCountry]
	PRIMARY KEY
	CLUSTERED
	([TaxClassCountryID])
	
CREATE NONCLUSTERED INDEX [IX_COM_TaxClassCountry_CountryID]
	ON [COM_TaxClassCountry] ([CountryID]) 
CREATE UNIQUE NONCLUSTERED INDEX [IX_COM_TaxClassCountry_TaxClassID_CountryID]
	ON [COM_TaxClassCountry] ([TaxClassID], [CountryID]) 

ALTER TABLE [COM_TaxClassCountry]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_TaxCategoryCountry_CountryID_CMS_Country]
	FOREIGN KEY ([CountryID]) REFERENCES [CMS_Country] ([CountryID])
ALTER TABLE [COM_TaxClassCountry]
	CHECK CONSTRAINT [FK_COM_TaxCategoryCountry_CountryID_CMS_Country]
ALTER TABLE [COM_TaxClassCountry]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_TaxCategoryCountry_TaxClassID_COM_TaxClass]
	FOREIGN KEY ([TaxClassID]) REFERENCES [COM_TaxClass] ([TaxClassID])
ALTER TABLE [COM_TaxClassCountry]
	CHECK CONSTRAINT [FK_COM_TaxCategoryCountry_TaxClassID_COM_TaxClass]
