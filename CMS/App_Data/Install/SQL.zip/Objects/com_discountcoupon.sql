CREATE TABLE [COM_DiscountCoupon] (
		[DiscountCouponID]               [int] IDENTITY(1, 1) NOT NULL,
		[DiscountCouponDisplayName]      [nvarchar](200) NOT NULL,
		[DiscountCouponIsExcluded]       [bit] NOT NULL,
		[DiscountCouponValidFrom]        [datetime2](7) NULL,
		[DiscountCouponValidTo]          [datetime2](7) NULL,
		[DiscountCouponValue]            [float] NOT NULL,
		[DiscountCouponIsFlatValue]      [bit] NOT NULL,
		[DiscountCouponCode]             [nvarchar](200) NOT NULL,
		[DiscountCouponGUID]             [uniqueidentifier] NULL,
		[DiscountCouponLastModified]     [datetime2](7) NULL,
		[DiscountCouponSiteID]           [int] NULL
) 
ALTER TABLE [COM_DiscountCoupon]
	ADD
	CONSTRAINT [PK_COM_DiscountCoupon]
	PRIMARY KEY
	NONCLUSTERED
	([DiscountCouponID])
	
ALTER TABLE [COM_DiscountCoupon]
	ADD
	CONSTRAINT [DEFAULT_COM_DiscountCoupon_DiscountCouponCode]
	DEFAULT (N'') FOR [DiscountCouponCode]
ALTER TABLE [COM_DiscountCoupon]
	ADD
	CONSTRAINT [DEFAULT_COM_DiscountCoupon_DiscountCouponDisplayName]
	DEFAULT (N'') FOR [DiscountCouponDisplayName]
ALTER TABLE [COM_DiscountCoupon]
	ADD
	CONSTRAINT [DEFAULT_COM_DiscountCoupon_DiscountCouponIsExcluded]
	DEFAULT ((0)) FOR [DiscountCouponIsExcluded]
ALTER TABLE [COM_DiscountCoupon]
	ADD
	CONSTRAINT [DEFAULT_COM_DiscountCoupon_DiscountCouponIsFlatValue]
	DEFAULT ((0)) FOR [DiscountCouponIsFlatValue]
ALTER TABLE [COM_DiscountCoupon]
	ADD
	CONSTRAINT [DEFAULT_COM_DiscountCoupon_DiscountCouponValue]
	DEFAULT ((0)) FOR [DiscountCouponValue]
CREATE NONCLUSTERED INDEX [IX_COM_DiscountCoupon_DiscountCouponCode]
	ON [COM_DiscountCoupon] ([DiscountCouponCode]) 
CREATE NONCLUSTERED INDEX [IX_COM_DiscountCoupon_DiscountCouponSiteID]
	ON [COM_DiscountCoupon] ([DiscountCouponSiteID]) 
CREATE CLUSTERED INDEX [IX_COM_DiscountCoupon_DiscoutCouponDisplayName]
	ON [COM_DiscountCoupon] ([DiscountCouponDisplayName]) 

ALTER TABLE [COM_DiscountCoupon]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_DiscountCoupon_DiscountCouponSiteID_CMS_Site]
	FOREIGN KEY ([DiscountCouponSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [COM_DiscountCoupon]
	CHECK CONSTRAINT [FK_COM_DiscountCoupon_DiscountCouponSiteID_CMS_Site]
