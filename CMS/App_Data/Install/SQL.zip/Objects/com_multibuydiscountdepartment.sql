CREATE TABLE [COM_MultiBuyDiscountDepartment] (
		[MultiBuyDiscountID]     [int] NOT NULL,
		[DepartmentID]           [int] NOT NULL
) 
ALTER TABLE [COM_MultiBuyDiscountDepartment]
	ADD
	CONSTRAINT [PK_COM_MultiBuyDiscountDepartment]
	PRIMARY KEY
	CLUSTERED
	([MultiBuyDiscountID], [DepartmentID])
	
ALTER TABLE [COM_MultiBuyDiscountDepartment]
	ADD
	CONSTRAINT [DEFAULT_COM_MultiBuyDiscountDepartment_DepartmentID]
	DEFAULT ((0)) FOR [DepartmentID]
CREATE NONCLUSTERED INDEX [IX_COM_MultiBuyDiscountDepartment_DepartmentID]
	ON [COM_MultiBuyDiscountDepartment] ([DepartmentID]) 

ALTER TABLE [COM_MultiBuyDiscountDepartment]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_MultiBuyDiscountDepartment_DepartmentID_COM_Department]
	FOREIGN KEY ([DepartmentID]) REFERENCES [COM_Department] ([DepartmentID])
ALTER TABLE [COM_MultiBuyDiscountDepartment]
	CHECK CONSTRAINT [FK_COM_MultiBuyDiscountDepartment_DepartmentID_COM_Department]
ALTER TABLE [COM_MultiBuyDiscountDepartment]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_MultiBuyDiscountDepartment_MultiBuyDiscountID_COM_MultiBuyDiscount]
	FOREIGN KEY ([MultiBuyDiscountID]) REFERENCES [COM_MultiBuyDiscount] ([MultiBuyDiscountID])
ALTER TABLE [COM_MultiBuyDiscountDepartment]
	CHECK CONSTRAINT [FK_COM_MultiBuyDiscountDepartment_MultiBuyDiscountID_COM_MultiBuyDiscount]
