CREATE TABLE [CMS_RoleApplication] (
		[RoleID]        [int] NOT NULL,
		[ElementID]     [int] NOT NULL
) 
ALTER TABLE [CMS_RoleApplication]
	ADD
	CONSTRAINT [PK_CMS_RoleApplication]
	PRIMARY KEY
	CLUSTERED
	([RoleID], [ElementID])
	
CREATE NONCLUSTERED INDEX [IX_CMS_RoleApplication]
	ON [CMS_RoleApplication] ([ElementID]) 

ALTER TABLE [CMS_RoleApplication]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_RoleApplication_CMS_Role]
	FOREIGN KEY ([RoleID]) REFERENCES [CMS_Role] ([RoleID])
ALTER TABLE [CMS_RoleApplication]
	CHECK CONSTRAINT [FK_CMS_RoleApplication_CMS_Role]
ALTER TABLE [CMS_RoleApplication]
	WITH CHECK
	ADD CONSTRAINT [FK_CMS_RoleApplication_CMS_UIElement]
	FOREIGN KEY ([ElementID]) REFERENCES [CMS_UIElement] ([ElementID])
ALTER TABLE [CMS_RoleApplication]
	CHECK CONSTRAINT [FK_CMS_RoleApplication_CMS_UIElement]
